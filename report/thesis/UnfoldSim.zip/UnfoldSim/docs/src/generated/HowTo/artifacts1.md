```@meta
EditURL = "../../../literate/HowTo/artifacts.jl"
```

Test for artifactsd

---

*This page was generated using [Literate.jl](https://github.com/fredrikekre/Literate.jl).*

