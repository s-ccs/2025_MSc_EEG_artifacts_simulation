```@meta
EditURL = "../../../literate/reference/overview.jl"
```

# Overview of functionality
A UnfoldSim simulation has four ingredients: Design, Component, Onset and Noise. Here we provide a short overview of the implemented types.

### Setup
```@raw html
<details>
<summary>Click to expand</summary>
```

````@example overview
# Load required packages
using UnfoldSim
using InteractiveUtils
````

```@raw html
</details>
```

## Design
Designs define the experimental design. They can be nested, e.g. `RepeatDesign(SingleSubjectDesign,10)` would repeat the generated design-dataframe 10x.

````@example overview
subtypes(AbstractDesign)
````

## Component
Components define a signal. Some components can be nested, e.g. `LinearModelComponent|>MultichannelComponent`, see the multi-channel tutorial for more information.

````@example overview
subtypes(AbstractComponent)
````

## Onsets
Onsets define the distance between events in the continuous signal.

````@example overview
subtypes(AbstractOnset)
````

## Noise
Choose the noise you need!

````@example overview
subtypes(AbstractNoise)
````

---

*This page was generated using [Literate.jl](https://github.com/fredrikekre/Literate.jl).*

