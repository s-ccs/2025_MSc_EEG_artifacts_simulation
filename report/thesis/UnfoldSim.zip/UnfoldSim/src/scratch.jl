struct EyeMovement <: AbstractContinuousSignal
    controlsignal
end
    
function UnfoldSim.simulate(rng::AbstractRNG,d::AbstractDesign,c::AbstractComponent,o::AbstractOnset,s::AbstractContinuousSignal)
controlsignal::Matrix(feat,time) = generate_controlsignal(deepcopy(rng),s)
signal::Matrix = simulate_continuoussignal(deepcopy(rng),s,controlsignal)
end

function simulate_continuoussignal(rng,s::EyeMovement,controlsignal)
=> Maaniks EM simulation function
returns signal
end

generate_controlsignal(rng,s::TRF) = rand(rng,length(s)) # s.controlsignal
simulate_continuoussignal(rng,s::TRF,controlsignal) = conv(controlsignal, generate_component(rng,s))


s needs to be a s::Vector{Union{...}}


# ---------------


struct EyeModel <: AbstractHeadmodel
    orientation::Matrix{Float64}
    eyeleft_idx::Int
    eyeright_idx::Int
    eyecenter_left_idx::Vector{Float64}
    eyecenter_right_idx::Vector{Float64}
end

# -------------------


# simulate_eyemovement

# option 1:  
    # precalculate all weights and orientations for ensemble and crd respectively, then call the same lower function once.
    # results in more for-loops through the gazevectors but clearer code

# option 2: loop through gazevectors here, 



# ---------------------


# 09Sep - probably everything noise-related would be added here already by the time the respective results of simulate() are returned
    # for what USAjl adds rn i.e. artifacts, the simulate_continuoussignal() call will go out separately and return just the artifact, for other (NoiseType // NoNoise) it will just call existing simulate()
    # then add everything at time points 
    # if epochs wanted, probably epoch here? Then in case the existing simulate() call already did epoch the data, we need to stick it back together OR reshape the artifact data and add. 
    # depends on if the artifact is event based or continuous ig?
    # add_responses!() might be useful here



# --------------------

# sinusoids = zeros(length(harmonics), n_samples)
#     for ix=1:length(harmonics) # OR for each harmonic multiplier
#         sinusoids[ix] = sin.(2π * base_freq * k ./ sampling_rate)
#     end



-----------------

30sep

harmonics_signals = [sin.(2 * pi * (base_freq.*h)/sampling_rate .* k) for h in harmonics].*weights_harmonics
# harmonics_signals = [sin.(2 * pi * (base_freq.*harmonics[h])/sampling_rate .* k).*weights_harmonics[h] for h in 1:length(harmonics)]

@show "harmonics_signals size:",size(harmonics_signals), size.(harmonics_signals)
# harmonics_signals = [harmonics_signals...] #reduce(vcat,harmonics_signals)
# @show "harmonics_signals size:",size(harmonics_signals), size.(harmonics_signals)
return reduce(+,harmonics_signals)



    # once all other signals are the same size, pass any one of them to PLN simulation as controlsignal to get the right length
    plns = [simulate_continuoussignal(rng,p,combined_signals[1],sim) for p in s if p isa PowerLineNoise]
    # sum_pln = reshape(reduce(+,pln),1,:) # make it a 1 x time array instead of a column vector, so that it can be broadcasted to all channels
    sum_pln = plns == [] ? zeros(size(combined_signals[1],2)) : reduce(+,plns)
    # sum_pln =  # make it a 1 x time array instead of a column vector, so that it can be broadcasted to all channels
    # sum_signals = reduce(+, combined_signals) # sum of eeg and artifacts
    sum_signals = reduce(+, combined_signals) .+ reshape(sum_pln,1,:)
----------