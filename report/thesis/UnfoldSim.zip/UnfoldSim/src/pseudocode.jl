# Meeting 2025-10-14 13:45   

generate_controlsignal(PLN -> AbstractMatrix) -> identity function

generate_controlsignal(PLN -> nothing defined OR functions given) 
	return generator/function: takes size of eeg matrix (chan x time), generates controlsignal matrix (weights) and returns it
end

simulate_continuoussignal
	simulate_pln  --> single channel PLN incl all harmonics
	return generator/function 
				--> takes size of controlsignal matrix (chan x time), 
					calls generate_controlsignal to get matrix (weights), 
					applies weights and returns final PLN artifact
end


simulate
	cs = generate_controlsignal.(s)
	artifacts = simulate_continuoussignal.(cs) ------> some are matrices and some are functions
	get size of first eager matrix (=eeg)
	evaluate `artifacts`-functions
	add all artifacts & return sum
end 