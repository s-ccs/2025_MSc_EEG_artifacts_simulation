function simulate_continuoussignal(rng::AbstractRNG, s::EyeMovement, controlsignal::AbstractMatrix, sim::Simulation)
    # at the lowest level, eyemovement simulation takes a controlsignal = Matrix having size 3 x n_timepoints i.e. a set of gaze direction vectors     
    headmodel = s.headmodel
    eye_model = s.eye_model
    return simulate_eyemovement(headmodel,controlsignal, eye_model)
end

"""
controlsignal: actual weights (n_channels x n_timepoints) to be applied to the simulated single-channel powerline noise
"""
function simulate_continuoussignal(rng::AbstractRNG, s::PowerLineNoise, controlsignal::AbstractMatrix, sim::Simulation)
    # harmonics are always weighted the same relative to each other, irrespective of `channel x timepoint` weights applied later via controlsignal.
    
    base_freq = s.base_freq
    harmonics = s.harmonics
    sampling_rate = s.sampling_rate
    weights_harmonics = s.weights_harmonics

    n_samples = size(controlsignal)[end]
    k = 0:1:n_samples-1
    # TODO (future) add check for nyquist criterion? -> warn or error?

    harmonics_signals = [sin.(2 * pi * (base_freq.*h)/sampling_rate .* k) for h in harmonics].*weights_harmonics
    
    return reduce(+,harmonics_signals)' .*controlsignal
end


function simulate_continuoussignal(rng::AbstractRNG, s::AbstractNoise, controlsignal::AbstractArray, sim::Simulation)
    return reshape(simulate_noise(rng,s,length(controlsignal)),size(controlsignal)) .* controlsignal
end

function simulate_continuoussignal(rng::AbstractRNG, s::UserDefinedContinuousSignal, controlsignal::AbstractArray, sim::Simulation)
    return s.signal .* controlsignal # the user has already defined what they want
end



# generate_controlsignal - returns controlsignal for the specified type of AbstractContinuousSignal.
# also takes the simulation object since it might influence the generated controlsignal (e.g. generate blinks right after event A -> controlsignal depends on the design) 

function generate_controlsignal(rng::AbstractRNG, cs::AbstractContinuousSignal, sim::Simulation)
    return generate_controlsignal(deepcopy(rng), cs.controlsignal, sim)
end


# for EyeMovement, always return a 3 x n_timepoints matrix containing gaze direction vectors (n_timepoints number of gaze vectors, in 3 dimensions)

function generate_controlsignal(rng::AbstractRNG, cs::GazeDirectionVectors, sim::Simulation)
    @assert size(cs.val)[1] == 3 "Please make sure gaze data has the shape 3 x n_timepoints."
    return cs.val
end

function generate_controlsignal(rng::AbstractRNG, cs::HREFCoordinates, sim::Simulation)
    return reduce(hcat,gazevec_from_angle_3d.(cs.val[1,:],cs.val[2,:]))
end


 # for PowerLineNoise we do not yet know the required n_timepoints, so we postpone controlsignal generation until the eeg and the known-size artifacts have already been generated
function generate_controlsignal(rng::AbstractRNG, cs::PowerLineNoise, sim::Simulation)
    # in future we may want to allow generating the noise on only a particular channel, which could be done via changing the controlsignal weights.
    return nothing
end

# AbstractNoise: returns nothing for now, however in future the controlsignal for AbstractNoise may depend on the Simulation.
function generate_controlsignal(rng::AbstractRNG, cs::AbstractNoise, sim::Simulation)
    return nothing
end

function generate_controlsignal(rng::AbstractRNG, cs::DriftNoise, sim::Simulation)
    return nothing
end

# identity function - in case the user already specified the final controlsignal while creating the artifact
function generate_controlsignal(rng::AbstractRNG, cs::AbstractMatrix, sim::Simulation)
    return cs
end



# simulate_continououssignal - simulates the continuoussignal based on the signal type and the specified controlsignal.

function simulate_continuoussignal(rng::AbstractRNG, s::Union{ARDriftNoise,DCDriftNoise,LinearDriftNoise}, controlsignal::AbstractMatrix, sim::Simulation)
     # call the singlechannel simulate_continououssignal(..., controlsignal[i,:]) for each row (channel) of controlsignal
     return hcat(map(controlsignal_channelwise->simulate_continuoussignal(rng,s,controlsignal_channelwise,sim), eachrow(controlsignal))...)'
end

function simulate_continuoussignal(rng::AbstractRNG, s::LinearDriftNoise, controlsignal::AbstractVector, sim::Simulation)
    # simulate single-channel drift
    n_samples = size(controlsignal)[end]
    return  range(0,1,length=n_samples).*
            (rand((rng))*2-1) .*    # slope of the line for this particular channel
            s.scaling_factor .*     # global scaling factor for the entire current LinearDriftNoise
            controlsignal           # user-controllable weights (1 x timepoint : current_channel vector taken from the entire artifact controlsignal) 
end

function simulate_continuoussignal(rng::AbstractRNG, s::ARDriftNoise, controlsignal::AbstractVector, sim::Simulation)
    n_samples = size(controlsignal)[end]
    return cumsum(s.σ .* randn((rng),n_samples).*controlsignal) 
end

function simulate_continuoussignal(rng::AbstractRNG, s::DCDriftNoise, controlsignal::AbstractVector, sim::Simulation)
    n_samples = size(controlsignal)[end]
    return ones(n_samples).*rand((rng)).* s.scaling_factor .*controlsignal
end

# generic drift noise: contains multiple fields having different driftnoise types. Simulate the artifact for each of these.
function simulate_continuoussignal(rng::AbstractRNG, s::DriftNoise, controlsignal::AbstractMatrix, sim::Simulation)
    fn = fieldnames(DriftNoise)
    all_s = []
    for f in fn
        field = getfield(s,f)
        push!(all_s,simulate_continuoussignal(rng,field,field.controlsignal,sim))
    end

    return sum(all_s)
end