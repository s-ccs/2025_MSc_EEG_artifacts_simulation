"""
Construct the gaze vector in 3-D world coordinates, given the gaze angle (in degrees) as measured from the center gaze (looking straight ahead) in the world x-y plane. Z-component is always 0.  
"""
function gazevec_from_angle(angle_deg)
	# just x,y plane. gaze angle measured from front neutral gaze, not from x-axis
	return [sind(angle_deg) cosd(angle_deg) 0]
end

"""
Calculate the gaze vector in 3-D world coordinates, given the horizontal and vertical angles (in degrees) 
from center gaze direction i.e. looking straight ahead.
Utility function: used to calculate gaze direction vectors from HREF coordinates.
"""
function gazevec_from_angle_3d(angle_H, angle_V)
	# since angles are measured from center gaze position => use complementary angle for θ (horizontal direction); 
    # ϕ (vertical direction) is already measured upwards from the x-y plane, according to the conventions of CoordinateTransformations.jl
	return Vector{Float32}(CartesianFromSpherical()(Spherical(1, deg2rad(90-angle_H), deg2rad(angle_V))))
end


"""
    read_eyemodel(;p::String = "HArtMuT_NYhead_extra_eyemodel.mat")

Read and return the HArtMuT eye model from the given file path. Utility function.

# Fields
- `p::String` (optional): Path of the file from which to read the eye model. 

# Returns
- `model`: Eye model read from the specified file path.
"""
function read_eyemodel(;p::String = "HArtMuT_NYhead_extra_eyemodel.mat")
    file = matopen(p);
    hartmut = read(file,"eyemodel")
    close(file)
    hartmut["label"] = hartmut["labels"]
    delete!(hartmut,"labels")
    hartmut
end

"""
For each of a given set of labels, find the indices of all the sources in the given hartmut model which have that label. Utility function.

Arguments:
- `headmodel`: Head model containing the sources in which to search for labels
- `labels::Vector{String}`: Labels to search for. 

Returns:
- `labelsourceindices::Dict`: Dict with the keys being the given labels and the values being the corresponding indices of sources with that label in the given model. 
"""
function hart_indices_from_labels(headmodel,labels::AbstractVector=["dummy"])
    labelsourceindices = Dict()
    for l in labels
        labelsourceindices[l] = findall(k->occursin(l,k),headmodel["label"][:])
    end
    return labelsourceindices
end


"""
Calculate orientation vectors from the given positions with respect to the reference. The vectors are normalized to have length 1. 
`direction` is by default "away" from the reference point; set `direction="towards"` to calculate orientations towards the reference point.
Utility function.
"""
function calc_orientations(reference, positions; direction::String="away")
    if direction=="towards"
        orientation_vecs = reference .- positions
    else 
        orientation_vecs = positions .- reference
    end
    return orientation_vecs ./ norm.(eachrow(orientation_vecs))
end


"""
Return the angle (in degrees) between two 3-D vectors in Cartesian coordinates. Utility function.
"""
function angle_between(a,b) 
    return acosd.(dot(a, b)/(norm(a)*norm(b)))
end


"""
    is_corneapoint(orientation::Vector{Float64}, gazedir::Vector{Float64}, max_cornea_angle_deg::Float64)

Return 1 if the angle between the given orientation vector and the gaze direction vector is less than or equal to the given maximum cornea angle; else return -1. Utility function.

"""
function is_corneapoint(orientation::Vector{Float64}, gazedir::Vector, max_cornea_angle_deg::Float64)
	if(angle_between(orientation,gazedir)<=max_cornea_angle_deg)
		return 1
	else 
		return -1
	end
end


"""
Calculate the leadfield (assuming ensemble model of the eye) for a given gaze direction.

# Arguments
- `eyemodel`: Head model containing the sources
- `sim_idx::Vector{Int}`: Indices of the sources which should be included in the calculation.
- `gazedir::Vector{Float64}`: Gaze direction vector in 3-D space, pointing from the eye center to the gaze target. 
- `max_cornea_angle_deg::Float64`: Angle defining the cone within which a point will be considered as a cornea point based on the gaze direction.

# Returns
- Ensemble-model leadfield calculated for the given gaze direction, source indices and cornea angle. 

"""
function ensemble_leadfield(eyemodel, sim_idx::Vector{Int}, gazedir::Vector{Float64}, max_cornea_angle_deg::Float64)
	mag_model = magnitude(eyemodel["leadfield"],eyemodel["orientation"])
	source_weights = zeros(size(eyemodel["pos"])[1]) # all sources other than those defined by sim_idx will be set to zero magnitude 
	source_weights[sim_idx] .= mapslices(x -> is_corneapoint(x,gazedir,max_cornea_angle_deg), eyemodel["orientation"][sim_idx,:],dims=2)
	
	weighted_sum = sum(mag_model[:,idx].* source_weights[idx] for idx in sim_idx)
	return weighted_sum
end


"""
Calculate the leadfield resulting from activating only the specified source points, weighted according to the given weight vector. 
It is assumed that the orientations for the respective source points are already set in the given head model.
Used for simulating individual leadfields in eye movement simulation.
"""
function generate_eyegaze_eeg(eyemodel, src_idx::AbstractVector, weights::AbstractVector)

    mag = magnitude(eyemodel["leadfield"],eyemodel["orientation"])
    signal = sum(mag[:,idx].* weights[idx] for idx in src_idx)

    return signal
end


"""
    simulate_eyemovement(headmodel, gazevectors::AbstractMatrix, eye_model::String)

Simulate the eye movement and return the corresponding scalp potentials at each of the channels, 
given a head model, an array of gaze direction vectors defining the eye movement, and optionally an eye-model type. 

# Arguments
- `headmodel`: Head model to be used.
- `gazevectors`: Gaze direction vectors (in Cartesian coordinates) to define the eye movement trajectory. The vector should point from the eyes towards the gaze target. 
- `eye_model::String` (optional): Choice of model to use for the eye. Options available are "crd" (default) and "ensemble".

# Returns
- Matrix of size n_channels x n_gazepoints containing the eyeball-generated leadfield for each time point based on the corresponding gaze direction vectors. 
"""
function simulate_eyemovement(headmodel, gazevectors::AbstractMatrix, eye_model::String)
    # when gaze direction vector changes, 
    # CRD: orientation changes, weight stays the same (=1 for all points)
    # Ensemble: orientation stays the same, weight changes (=1 for cornea points, -1 for retina points, calculated based on gaze direction)

    # leadfields: matrix with dimensions [electrodes x n_gazepoints] 
    leadfields = zeros(size(headmodel["electrodes"]["pos"])[1],size(gazevectors)[2])

    # weights: matrix of dimensions [n_channel x n_gazevec]

    if eye_model=="crd"
        weights = ones(size(headmodel["pos"])[1])
        src_idx = [headmodel["eyecenter_left_idx"] headmodel["eyecenter_right_idx"]]
        # select eye centers as source points; set orientation = each respective gazevector and find corresponding leadfield
        
        for ix = 1:size(gazevectors)[2]
            headmodel["orientation"][headmodel["eyecenter_left_idx"],:] = gazevectors[:,ix]
            headmodel["orientation"][headmodel["eyecenter_right_idx"],:] = gazevectors[:,ix]
            # or just use src_idx - will help later if we want to simulate just for one eye or so

            leadfields[:,ix] = generate_eyegaze_eeg(headmodel, vec(src_idx), weights)
        end

    elseif eye_model=="ensemble"
        weights = zeros(size(headmodel["pos"])[1])

        # select cornea and retina sources to simulate; set orientation; simulate EEG for each of the gaze vectors

        # indices in headmodel, of the points which we want to use to simulate data, i.e. retina & cornea. used for ensemble simulation. 
        src_idx = [headmodel["eyeleft_idx"]; headmodel["eyeright_idx"]]
        
        
        for ix in 1:size(gazevectors,2)
            # weight changes depending on retina/cornea type based on current gazevector
            weights[src_idx] .= mapslices(x -> is_corneapoint(x,gazevectors[:,ix],54.0384), headmodel["orientation"][src_idx,:],dims=2)
            # TODO (future outlook): change the above line to separately calculate weights for left and right eye if giving gazepoints and calculating gaze vectors separately. or just run simulate_eyemovement twice, once with gazevectors based on left eye and once with right eye? 

            leadfields[:,ix] = generate_eyegaze_eeg(headmodel, src_idx, weights)
        end

    else
        @error "Neither CRD nor Ensemble model selected. No eye movement simulation performed."
    end

    return leadfields
end


"""
Utility function: read the eye model from a mat file, remove channels Nk1-Nk4; 
calculate left/right eye source indices, eye centers, orientations away from respective eye centers; and add these to the eyemodel as properties. 
Return imported model with additional properties as mentioned above.
"""
function import_eyemodel(; labels=[
    r"EyeRetina_Choroid_Sclera_left$" # match the end of the search term, or else it also matches "leftright" sources.
    ,r"EyeRetina_Choroid_Sclera_right$"
    ,"EyeCornea_left" # eyemodel - only one set of sources per eye, and the labels are different, compared to the full HArtMuT model
    ,"EyeCornea_right"
    ,"EyeCenter_left"
    ,"EyeCenter_right"
], modelpath=joinpath(pkgdir(UnfoldSim),"src/HArtMuT_NYhead_extra_eyemodel_hull_mesh8_2025-03-01.mat")
)   
    eyemodel = read_eyemodel(; p=modelpath)
    remove_indices = [164, 165, 166, 167] # since eyemodel structure doesn't exactly correspond to the main hartmut mat structure expected by the read_new_hartmut function, just get the indices of the electrodes that it drops & drop the same indices from eyemodel directly 
    eyemodel["leadfield"] = eyemodel["leadfield"][Not(remove_indices), :, :]

    lsi_eyemodel = hart_indices_from_labels(eyemodel,labels) 

    # add electrode positions to eyemodel - import small headmodel temporarily since the eyemodel does not contain them
	hart_small = Hartmut()
	pos3d = hart_small.electrodes["pos"]
    eyemodel["electrodes"] = deepcopy(hart_small.electrodes)

    # add indices and positions of certain sets of sources, to make them easier to access
    eyemodel["eyeleft_idx"] = [ lsi_eyemodel["EyeCornea_left"] ; lsi_eyemodel[r"EyeRetina_Choroid_Sclera_left$"] ] # eyemodel_left_idx
    eyemodel["eyeright_idx"] = [ lsi_eyemodel["EyeCornea_right"] ; lsi_eyemodel[r"EyeRetina_Choroid_Sclera_right$"] ] # eyemodel_right_idx
    eyemodel["eyecenter_left_pos"] = eyemodel["pos"][lsi_eyemodel["EyeCenter_left"],:] # eye_center_L
    eyemodel["eyecenter_right_pos"] = eyemodel["pos"][lsi_eyemodel["EyeCenter_right"],:] # eye_center_R
    eyemodel["eyecenter_left_idx"] = lsi_eyemodel["EyeCenter_left"]
    eyemodel["eyecenter_right_idx"] = lsi_eyemodel["EyeCenter_right"]

    # add orientations (by default all set to zero)
	eyemodel["orientation"] = zeros(size(eyemodel["pos"]))

    # calculate eye surface sources' orientations away from the respective eye centers
    # later use negative weightage for the points where the source dipole points towards the center (i.e. the retina points).  
    eyemodel["orientation"][eyemodel["eyeleft_idx"],:] = calc_orientations(eyemodel["eyecenter_left_pos"], eyemodel["pos"][eyemodel["eyeleft_idx"],:])
    eyemodel["orientation"][eyemodel["eyeright_idx"],:] = calc_orientations(eyemodel["eyecenter_right_pos"], eyemodel["pos"][eyemodel["eyeright_idx"],:]) 

    return eyemodel
end

"""
Utility function: Find the approximate current gaze direction from the orientations of cornea-labelled sources.
"""
function find_avg_gazedir(eyemodel)
    # finding cornea centers and approximate gaze direction (as mean of cornea orientations)
    cornea_center_R = Statistics.mean(eyemodel["pos"][lsi_eyemodel["EyeCornea_right"],:],dims=1)
    cornea_center_L = Statistics.mean(eyemodel["pos"][lsi_eyemodel["EyeCornea_left"],:],dims=1)
    gazedir_R = mean(eyemodel["orientation"][lsi_eyemodel["EyeCornea_right"],:], dims=1).*10
    gazedir_L = mean(eyemodel["orientation"][lsi_eyemodel["EyeCornea_left"],:], dims=1).*10
end

#TODO (future): auto-find cornea max. angle from center and cornea point positions


function az_simulation()
    # import hartmut model - modified with new eye points
    eyemodel = import_eyemodel()

    # import href gaze coordinates
    sample_data = example_data_eyemovements()
    href_trajectory = sample_data[1:2,1:200]

    # setup basic ingredients for simulate
    design = SingleSubjectDesign(; conditions = Dict(:cond_A => ["level_A", "level_B"])) |> x -> RepeatDesign(x, 10);
    signal = LinearModelComponent(;
    basis = [0, 0, 0, 0.5, 1, 1, 0.5, 0, 0],
    formula = @formula(0 ~ 1 + cond_A),
    β = [1, 0.5],
    );
    hart = Hartmut();
    mc = UnfoldSim.MultichannelComponent(signal, hart => "Left Postcentral Gyrus");
    onset = UniformOnset(; width = 20, offset = 4);
    noise = PinkNoise(; noiselevel = 0.2);

    simulate(MersenneTwister(1), design, mc, onset, [EyeMovement(HREFCoordinates(href_trajectory), eyemodel, "ensemble"); noise; PowerLineNoise([0 0; 0 0], 50, [1 3 5], [0.001 0.0005 0], 1000)]);

end